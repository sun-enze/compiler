from compiler_oj import command_line


if __name__ == '__main__':
    command_line.main()
