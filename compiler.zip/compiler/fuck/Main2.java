import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.*;
import java.util.*;

public class Main{
	static class Type{
		String name;
		int array;
		//		List<Type>para;
		Type(mxstarParser.TypeContext ttx){
			name=ttx.getChild(0).getText();
			array=ttx.getChildCount()/2;
			//			para=new ArrayList<Type>();
		}
		Type(String o){
			name=o;
		}
		boolean equal(Type tmp){
			//System.out.printf(name+"\n"+tmp.name+"\n"+array+"\n"+tmp.array+"\n%b\n",tmp.name==name&&tmp.array==array);
			if(name.equals("void")!=tmp.name.equals("void"))
				return false;
			return tmp.name.equals(name)&&tmp.array==array||
				tmp.name=="null"&&(array!=0||!name.equals("int")&&!name.equals("bool")&&!name.equals("string"))||
				name=="null"&&(tmp.array!=0||!tmp.name.equals("int")&&!tmp.name.equals("bool")&&!tmp.name.equals("string"));
		}
	}
	static class Node{
		String kind;
		String id;
		List<Node>defs;
		Type type;
		List<Type>types;
		List<String>names;
		List<Node>expr;
		List<Node>stmts;
		Map<String,Def>scope;
		boolean isscope;
		boolean leftv;
		Node(){
			defs=new ArrayList<Node>();
			types=new ArrayList<Type>();
			names=new ArrayList<String>();
			expr=new ArrayList<Node>();
			stmts=new ArrayList<Node>();
			scope=new TreeMap<String,Def>();
		}
	}
	static int t1,t2;
	static Node visit(ParseTree now)throws Exception{
		for(int i=1;i<=t1;i++)
			System.out.printf("\t");
		t1++;
		System.out.print(now.getText());
		System.out.printf(":");
		//System.out.printf("???\n");
		Node tmp=new Node();
		if(now instanceof mxstarParser.CodeContext){
			System.out.printf("code\n");
			mxstarParser.CodeContext ctx=(mxstarParser.CodeContext)now;
			tmp.kind="code";
			tmp.isscope=true;
			for(ParseTree i:ctx.children)
				tmp.defs.add(visit(i));
		}
		else if(now instanceof mxstarParser.ClassdefContext){
			System.out.printf("classdef\n");
			mxstarParser.ClassdefContext ctx=(mxstarParser.ClassdefContext)now;
			tmp.kind="classdef";
			tmp.isscope=true;
			tmp.id=ctx.Name().getText();
			for(int i=3;i+1<ctx.getChildCount();i++)
				tmp.defs.add(visit(ctx.getChild(i)));
		}
		else if(now instanceof mxstarParser.FuncdefContext){
			System.out.printf("func\n");
			mxstarParser.FuncdefContext ctx=(mxstarParser.FuncdefContext)now;
			tmp.kind="funcdef";
			tmp.isscope=true;
			tmp.id=ctx.Name(0).getText();
			tmp.type=new Type(ctx.type(0));
			for(int i=1;i<ctx.type().size();i++){
				tmp.types.add(new Type(ctx.type(i)));
				tmp.names.add(ctx.Name(i).getText());
			}
			for(ParseTree i:ctx.statement())
				tmp.stmts.add(visit(i));
		}
		else if(now instanceof mxstarParser.ConstructfuncdefContext){
			System.out.printf("construct\n");
			mxstarParser.ConstructfuncdefContext ctx=(mxstarParser.ConstructfuncdefContext)now;
			tmp.kind="construct";
			tmp.isscope=true;
			tmp.id=ctx.Name().getText();
			for(ParseTree i:ctx.statement())
				tmp.stmts.add(visit(i));
		}
		else if(now instanceof mxstarParser.VardefContext){
			System.out.printf("vardef\n");
			mxstarParser.VardefContext ctx=(mxstarParser.VardefContext)now;
			tmp.kind="vardef";
			tmp.type=new Type(ctx.type());
			for(int i=1;i<ctx.getChildCount();i+=2){
				tmp.names.add(ctx.getChild(i).getText());
				if(ctx.getChild(i+1).getText().equals("=")){
					tmp.expr.add(visit(ctx.getChild(i+2)));
					i+=2;
				}
				else tmp.expr.add(null);
			}
		}
		else if(now instanceof mxstarParser.StatementContext){
			System.out.printf("statement\n");
			if(now instanceof mxstarParser.S1Context){
				mxstarParser.S1Context ctx=(mxstarParser.S1Context)now;
				tmp.kind="braces";
				tmp.isscope=true;
				for(ParseTree i:ctx.statement())
					tmp.stmts.add(visit(i));
			}
			else if(now instanceof mxstarParser.S2Context){
				tmp.kind="empty";
			}
			else if(now instanceof mxstarParser.S3Context){
				mxstarParser.S3Context ctx=(mxstarParser.S3Context)now;
				tmp=visit(ctx.vardef());
			}
			else if(now instanceof mxstarParser.S4Context){
				mxstarParser.S4Conteisscopext ctx=(mxstarParser.S4Context)now;
				tmp=visit(ctx.expr());
			}
			else if(now instanceof mxstarParser.S5Context){
				tmp.kind="break";
			}
			else if(now instanceof mxstarParser.S6Context){
				tmp.kind="continue";
			}
			else if(now instanceof mxstarParser.S7Context){
				mxstarParser.S7Context ctx=(mxstarParser.S7Context)now;
				tmp.kind="return";
				if(ctx.expr()!=null)
					tmp.expr.add(visit(ctx.expr()));
			}
			else if(now instanceof mxstarParser.S8Context){
				mxstarParser.S8Context ctx=(mxstarParser.S8Context)now;
				tmp.kind="if";
				tmp.expr.add(visit(ctx.expr()));
				for(ParseTree i:ctx.statement()){
					Node o;
					tmp.stmts.add(o=visit(i));
					if(o.kind=="vardef")
						o.isscope=true;
				}
			}
			else if(now instanceof mxstarParser.S9Context){
				mxstarParser.S9Context ctx=(mxstarParser.S9Context)now;
				tmp.kind="while";
				tmp.expr.add(visit(ctx.expr()));
				tmp.stmts.add(visit(ctx.statement()));
				if(tmp.stmts.get(0).kind=="vardef")
					tmp.stmts.get(0).isscope=true;
			}
			else if(now instanceof mxstarParser.S10Context){
				mxstarParser.S10Context ctx=(mxstarParser.S10Context)now;
				tmp.kind="for";
				for(int i=2,j=1;j<=3;i++,j++)
					if(ctx.getChild(i).getText().equals(";")||ctx.getChild(i).getText().equals(")"))
						tmp.expr.add(null);
					else tmp.expr.add(visit(ctx.getChild(i++)));
				tmp.stmts.add(visit(ctx.statement()));
				if(tmp.stmts.get(0).kind=="vardef")
					tmp.stmts.get(0).isscope=true;
			}
			else throw new Exception();
		}
		else if(now instanceof mxstarParser.ExprContext){
			System.out.printf("expr\n");
			if(now instanceof mxstarParser.E0Context||
				now instanceof mxstarParser.E1Context||
				now instanceof mxstarParser.E2Context||
				now instanceof mxstarParser.E3Context||
				now instanceof mxstarParser.E4Context||
				now instanceof mxstarParser.E5Context||
				now instanceof mxstarParser.E6Context){
					tmp.kind="const";
					tmp.id=now.getText();
			}
			else if(now instanceof mxstarParser.E7Context){
				tmp=visit(now.getChild(1));
			}
			else if(now instanceof mxstarParser.E8Context){
				mxstarParser.E8Context ctx=(mxstarParser.E8Context)now;
				tmp.kind="expr";
				tmp.id=".";
				tmp.expr.add(visit(ctx.expr()));
				tmp.names.add(ctx.Name().getText());
			}
			else if(now instanceof mxstarParser.E9Context){
				mxstarParser.E9Context ctx=(mxstarParser.E9Context)now;
				tmp.kind="expr";
				tmp.id="func";
				for(ParseTree i:ctx.expr())
					tmp.expr.add(visit(i));
			}
			else if(now instanceof mxstarParser.E10Context){
				mxstarParser.E10Context ctx=(mxstarParser.E10Context)now;
				tmp.kind="expr";
				tmp.id="[]";
				for(ParseTree i:ctx.expr())
					tmp.expr.add(visit(i));
			}
			else if(now instanceof mxstarParser.E11Context){
				mxstarParser.E11Context ctx=(mxstarParser.E11Context)now;
				tmp.kind="expr";
				String o=ctx.getChild(1).getText();
				if(o.equals("++"))tmp.id="++_";
				if(o.equals("--"))tmp.id="--_";
				tmp.expr.add(visit(ctx.expr()));
			}
			else if(now instanceof mxstarParser.E12Context){
				mxstarParser.E12Context ctx=(mxstarParser.E12Context)now;
				tmp.kind="expr";
				String o=ctx.getChild(0).getText();
				if(o.equals("++"))tmp.id="++";
				if(o.equals("--"))tmp.id="--";
				if(o.equals("~"))tmp.id="~";
				if(o.equals("!"))tmp.id="!";
				if(o.equals("-"))tmp.id="-";
				if(o.equals("+"))tmp.id="+";
				tmp.expr.add(visit(ctx.expr()));
			}
			else if(now instanceof mxstarParser.E13Context){
				mxstarParser.E13Context ctx=(mxstarParser.E13Context)now;
				tmp.kind="expr";
				tmp.id="new";
				tmp.names.add(ctx.getChild(1).getText());
				for(int i=3;i<ctx.getChildCount();i+=2){
					if(ctx.getChild(i).getText().equals("]"))tmp.expr.add(null);
					else if(ctx.getChild(i).getText().equals(")"));
					else{
						tmp.expr.add(visit(ctx.getChild(i)));
						i++;
					}
				}
			}
			else{
				tmp.kind="expr";
				String o=now.getChild(1).getText();
				if(o.equals("*"))tmp.id="*";
				if(o.equals("/"))tmp.id="/";
				if(o.equals("%"))tmp.id="%";
				if(o.equals("+"))tmp.id="+";
				if(o.equals("-"))tmp.id="-";
				if(o.equals("<<"))tmp.id="<<";
				if(o.equals(">>"))tmp.id=">>";
				if(o.equals("<"))tmp.id="<";
				if(o.equals(">"))tmp.id=">";
				if(o.equals("<="))tmp.id="<=";
				if(o.equals(">="))tmp.id=">=";
				if(o.equals("=="))tmp.id="==";
				if(o.equals("!="))tmp.id="!=";
				if(o.equals("&"))tmp.id="&";
				if(o.equals("^"))tmisscopep.id="^";
				if(o.equals("|"))tmp.id="|";
				if(o.equals("&&"))tmp.id="&&";
				if(o.equals("||"))tmp.id="||";
				if(o.equals("="))tmp.id="=";
				tmp.expr.add(visit(now.getChild(0)));
				tmp.expr.add(visit(now.getChild(2)));
			}
		}
		else throw new Exception();
		t1--;
		return tmp;
	}
	static class Def{
		String kind;
		Type type;
		Map<String,Def>defs;
		List<Type>para;
		Def(){
			defs=new TreeMap<String,Def>();
			para=new ArrayList<Type>();
		}
	}
	static List<Node>ancestor=new ArrayList<Node>();
	static void check(Node now)throws Exception{
		for(int i=1;i<=t2;i++)
			System.out.printf("\t");
		t2++;
		System.out.printf(now.kind+"\n");
		ancestor.add(now);
		if(now.kind=="code"){
			{
				Def d=new Def(),f;
				d.kind="class";
				now.scope.put("int",d);

				d=new Def();
				d.kind="class";
				now.scope.put("bool",d);

				d=new Def();
				d.kind="class";{
					f=new Def();
					f.kind="func";
					f.type=new Type("int");
					d.defs.put("length",f);

					f=new Def();
					f.kind="func";
					f.type=new Type("string");
					f.para.add(new Type("int"));
					f.para.add(new Type("int"));
					d.defs.put("substring",f);

					f=new Def();
					f.kind="func";
					f.type=new Type("int");
					d.defs.put("parseInt",f);

					f=new Def();
					f.kind="func";
					f.type=new Type("int");
					f.para.add(new Type("int"));
					d.defs.put("ord",f);
				}
				now.scope.put("string",d);

				f=new Def();
				f.kind="func";
				f.type=new Type("void");
				f.para.add(new Type("string"));
				now.scope.put("print",f);

				f=new Def();
				f.kind="func";
				f.type=new Type("void");
				f.para.add(new Type("string"));
				now.scope.put("println",f);

				f=new Def();
				f.kind="func";
				f.type=new Type("string");
				now.scope.put("getString",f);

				f=new Def();
				f.kind="func";
				f.type=new Type("int");
				now.scope.put("getInt",f);

				f=new Def();
				f.kind="func";
				f.type=new Type("string");
				f.para.add(new Type("int"));
				now.scope.put("toString",f);
			}
			for(Node i:now.defs)
				if(i.kind=="classdef"){
					if(now.scope.get(i.id)!=null)
						throw new Exception();
					Def cdef=new Def();
					cdef.kind="class";
					for(Node j:i.defs){
						if(j.kind=="funcdef"){
							if(cdef.defs.get(j.id)!=null)
								throw new Exception();
							Def fdef=new Def();
							fdef.kind="func";
							fdef.type=j.type;
							for(Type k:j.types)
								fdef.para.add(k);
							cdef.defs.put(j.id,fdef);
							i.scope.put(j.id,fdef);
						}
						else if(j.kind=="vardef")
							for(String k:j.names){
								if(cdef.defs.get(k)!=null)
									throw new Exception();
								//for(Node w:j.expr)
								//	if(w!=null)
								//		throw new Exception();
								Def vdef=new Def();
								vdef.kind="var";
								vdef.type=j.type;
								cdef.defs.put(k,vdef);
								i.scope.put(k,vdef);
							}
					}
					now.scope.put(i.id,cdef);
				}
				else if(i.kind=="funcdef"){
					if(now.scope.get(i.id)!=null)
						throw new Exception();
					Def fdef=new Def();
					fdef.kind="func";
					fdef.type=i.type;
					for(Type k:i.types)
						fdef.para.add(k);
					now.scope.put(i.id,fdef);
				}
			boolean havemain=false;
			for(Node i:now.defs){
				if(i.kind=="funcdef"&&i.id.equals("main")&&i.type.equal(new Type("int"))&&i.types.size()==0)
					havemain=true;
			}
			if(!havemain)throw new Exception();
			for(Node i:now.defs)
				check(i);
		}
		else if(now.kind=="classdef"){
			for(Node i:now.defs){
				check(i);
				if(i.kind=="funcdef"&&i.id.equals(now.id))
					throw new Exception();
			}
		}
		else if(now.kind=="funcdef"){
			if(!now.type.equal(new Type("void"))&&(
				ancestor.get(0).scope.get(now.type.name)==null||
				ancestor.get(0).scope.get(now.type.name).kind!="class"))
					throw new Exception();
			for(int i=0;i<now.types.size();i++){
				if(ancestor.get(0).scope.get(now.types.get(i).name)==null||
					ancestor.get(0).scope.get(now.types.get(i).name).kind!="class")
						throw new Exception();
				Def vdef=new Def();
				vdef.kind="var";
				vdef.type=now.types.get(i);
				now.scope.put(now.names.get(i),vdef);
			}
			for(Node i:now.stmts)
				check(i);
		}
		else if(now.kind=="construct"){
			Node fa=ancestor.get(ancestor.size()-2);
			if(!now.id.equals(fa.id))
				throw new Exception();
			for(Node i:now.stmts)
				check(i);
		}
		else if(now.kind=="vardef"){
			if(ancestor.get(0).scope.get(now.type.name)==null||
				ancestor.get(0).scope.get(now.type.name).kind!="class")
					throw new Exception();
			Node fa=null;
			for(Node i:ancestor)
				if(i.isscope==true)
					fa=i;
			for(int i=0;i<now.names.size();i++){
				if(now.expr.get(i)!=null){
					check(now.expr.get(i));
					if(!now.type.equal(now.expr.get(i).type))
						throw new Exception();
				}
				if(fa.kind!="classdef"){
					if(fa.scope.get(now.names.get(i))!=null)
						throw new Exception();
					Def vdef=new Def();
					vdef.kind="var";
					vdef.type=now.type;
					fa.scope.put(now.names.get(i),vdef);
				}
			}
		}
		else if(now.kind=="braces"){
			for(Node i:now.stmts)
				check(i);
		}
		else if(now.kind=="empty");
		else if(now.kind=="break"||now.kind=="continue"){
			Node fa=null;
			for(Node i:ancestor)
				if(i.kind=="while"||i.kind=="for")
					fa=i;
			if(fa==null)throw new Exception();
		}
		else if(now.kind=="return"){
			Node fa=null;
			for(Node i:ancestor)
				if(i.kind=="funcdef")
					fa=i;
			if(fa==null||fa.type.equal(new Type("void"))){
				if(now.expr.size()!=0)
					throw new Exception();
			}
			else{
				if(now.expr.size()==0)
					throw new Exception();
				check(now.expr.get(0));
				if(!fa.type.equal(now.expr.get(0).type))
					throw new Exception();
			}
		}
		else if(now.kind=="if"){
			check(now.expr.get(0));
			if(!now.expr.get(0).type.equal(new Type("bool")))
				throw new Exception();
			for(Node i:now.stmts)
				check(i);
		}
		else if(now.kind=="while"){
			check(now.expr.get(0));
			if(!now.expr.get(0).type.equal(new Type("bool")))
				throw new Exception();
			check(now.stmts.get(0));
		}
		else if(now.kind=="for"){
			for(Node i:now.expr)
				if(i!=null)check(i);
			if(now.expr.get(1)!=null&&!now.expr.get(1).type.equal(new Type("bool")))
				throw new Exception();
			check(now.stmts.get(0));
		}
		else if(now.kind=="const"){
			if(now.id.equals("this"))
				if(ancestor.get(1).kind=="classdef")
					now.type=new Type(ancestor.get(1).id);
				else throw new Exception();
			else if(now.id.charAt(0)>='0'&&now.id.charAt(0)<='9')
				now.type=new Type("int");
			else if(now.id.equals("true"))
				now.type=new Type("bool");
			else if(now.id.equals("false"))
				now.type=new Type("bool");
			else if(now.id.charAt(0)=='"')
				now.type=new Type("string");
			else if(now.id.equals("null"))
				now.type=new Type("null");
			else{
				Def d=null;
				for(Node i:ancestor)
					if(i.scope.get(now.id)!=null)
						d=i.scope.get(now.id);
				if(d==null||d.kind=="class")
					throw new Exception();
				if(d.kind=="var"){
					now.type=d.type;
					now.leftv=true;
				}
				else{
					now.type=new Type("*");
					now.types.add(d.type);
					now.types.addAll(d.para);
				}
			}
			System.out.printf("type/const:"+now.type.name+"\n");
		}
		else if(now.kind=="expr"){
			if(now.id=="."){
				check(now.expr.get(0));
				Type type=now.expr.get(0).type;
				if(type.array!=0){
					if(!now.names.get(0).equals("size"))
						throw new Exception();
					now.type=new Type("*");
					now.types.add(new Type("int"));
				}
				else{
					Def d=ancestor.get(0).scope.get(type.name);
					if(d==null||d.defs.get(now.names.get(0))==null)
						throw new Exception();
					d=d.defs.get(now.names.get(0));
					if(d.kind=="func"){
						now.type=new Type("*");
						now.types.add(d.type);
						now.types.addAll(d.para);
					}
					else{
						now.type=d.type;
						now.leftv=true;
					}
				}
			}
			else if(now.id=="func"){
				for(Node i:now.expr)
					check(i);
				Node f=now.expr.get(0);
				if(f.type.name!="*"||f.types.size()!=now.expr.size())
					throw new Exception();
				for(int i=1;i<f.types.size();i++)
					if(!f.types.get(i).equal(now.expr.get(i).type))
						throw new Exception();
				now.type=f.types.get(0);
				//now.leftv=true;
			}
			else if(now.id=="[]"){
				for(Node i:now.expr)
					check(i);
				if(now.expr.get(0).type.array==0||
					!now.expr.get(1).type.equal(new Type("int")))
						throw new Exception();
				now.type=new Type(now.expr.get(0).type.name);
				now.type.array=now.expr.get(0).type.array-1;
				now.leftv=true;
			}
			else if(now.id=="new"){
				Def d=ancestor.get(0).scope.get(now.names.get(0));
				if(d==null||d.kind!="class")throw new Exception();
				boolean empty=false;
				for(Node i:now.expr){
					if(i!=null){
						if(empty)throw new Exception();
						check(i);
						if(!i.type.equal(new Type("int")))
							throw new Exception();
					}
					else empty=true;
				}
				now.type=new Type(now.names.get(0));
				now.type.array=now.expr.size();
			}
			else if(now.expr.size()==1){
				check(now.expr.get(0));
				Type type=now.expr.get(0).type;
				if(now.id=="++_"||now.id=="--_"||
					now.id=="++"||now.id=="--"||
					now.id=="~"||now.id=="-"||now.id=="+"){
						if(!type.equal(new Type("int")))
							throw new Exception();
				}
				else if(now.id=="!"){
					if(!type.equal(new Type("bool")))
						throw new Exception();
				}
				else throw new Exception();
				if(now.id=="++_"||now.id=="--_"||now.id=="++"||now.id=="--")
					if(!now.expr.get(0).leftv)throw new Exception();
				if(now.id=="++"||now.id=="--")
					now.leftv=true;
				now.type=type;
			}
			else{
				check(now.expr.get(0));
				check(now.expr.get(1));
				Type t1=now.expr.get(0).type,t2=now.expr.get(1).type;
				String o=now.id;
				if(o=="*"||o=="/"||o=="%"||o=="<<"||o==">>"||o=="&"||o=="|"||o=="^"||o=="-"){
					if(!(t1.equal(t2)&&t1.equal(new Type("int"))))
						throw new Exception();
					now.type=t1;
				}
				else if(o=="+"||o==">"||o=="<"||o==">="||o=="<="){
					if(!(t1.equal(t2)&&(t1.equal(new Type("int"))||t1.equal(new Type("string")))))
						throw new Exception();
					now.type=o=="+"?t1:new Type("bool");
				}
				else if(o=="&&"||o=="||"){
					if(!(t1.equal(t2)&&t1.equal(new Type("bool"))))
						throw new Exception();
					now.type=t1;
				}
				else if(o=="=="||o=="!="){
					if(!t1.equal(t2))
						throw new Exception();
					now.type=new Type("bool");
				}
				else if(o=="="){
					if(!t1.equal(t2)||now.expr.get(0).leftv==false)
						throw new Exception();
					now.type=t1;
				}
				else throw new Exception();
			}
			System.out.printf("type/expr:"+now.type.name+"\n");
		}
		ancestor.remove(ancestor.size()-1);
		t2--;
	}
	public static void main(String[] args)throws IOException,Exception{
		InputStream is=new FileInputStream("test/test.txt");
//		System.setErr(null);
		Node root=visit((new mxstarParser(new CommonTokenStream(new mxstarLexer(new ANTLRInputStream(is))))).code());
		check(root);
		//throw new Exception();
	}
}
