// Generated from emxstar.g4 by ANTLR 4.7.2
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class emxstarParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.7.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, T__10=11, T__11=12, T__12=13, T__13=14, T__14=15, T__15=16, T__16=17, 
		T__17=18, T__18=19, T__19=20, T__20=21, T__21=22, T__22=23, T__23=24, 
		T__24=25, T__25=26, T__26=27, T__27=28, T__28=29, T__29=30, T__30=31, 
		T__31=32, Bool=33, Int=34, String=35, Null=36, Void=37, True=38, False=39, 
		If=40, Else=41, For=42, While=43, Break=44, Continue=45, Return=46, New=47, 
		Class=48, This=49, Id=50, Stringcon=51, Number=52, WhiteSpace=53, NewLine=54, 
		LineComment=55;
	public static final int
		RULE_program = 0, RULE_func = 1, RULE_funccon = 2, RULE_vari = 3, RULE_clas = 4, 
		RULE_type = 5, RULE_block = 6, RULE_statement = 7, RULE_expression = 8, 
		RULE_constant = 9, RULE_name = 10;
	private static String[] makeRuleNames() {
		return new String[] {
			"program", "func", "funccon", "vari", "clas", "type", "block", "statement", 
			"expression", "constant", "name"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'('", "','", "')'", "'='", "';'", "'{'", "'}'", "'['", "']'", 
			"'++'", "'--'", "'.'", "'+'", "'-'", "'!'", "'~'", "'*'", "'/'", "'%'", 
			"'<<'", "'>>'", "'<'", "'>'", "'<='", "'>='", "'=='", "'!='", "'&'", 
			"'^'", "'|'", "'&&'", "'||'", "'bool'", "'int'", "'string'", "'null'", 
			"'void'", "'true'", "'false'", "'if'", "'else'", "'for'", "'while'", 
			"'break'", "'continue'", "'return'", "'new'", "'class'", "'this'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, "Bool", "Int", 
			"String", "Null", "Void", "True", "False", "If", "Else", "For", "While", 
			"Break", "Continue", "Return", "New", "Class", "This", "Id", "Stringcon", 
			"Number", "WhiteSpace", "NewLine", "LineComment"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "emxstar.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public emxstarParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class ProgramContext extends ParserRuleContext {
		public List<FuncContext> func() {
			return getRuleContexts(FuncContext.class);
		}
		public FuncContext func(int i) {
			return getRuleContext(FuncContext.class,i);
		}
		public List<ClasContext> clas() {
			return getRuleContexts(ClasContext.class);
		}
		public ClasContext clas(int i) {
			return getRuleContext(ClasContext.class,i);
		}
		public List<VariContext> vari() {
			return getRuleContexts(VariContext.class);
		}
		public VariContext vari(int i) {
			return getRuleContext(VariContext.class,i);
		}
		public ProgramContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_program; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterProgram(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitProgram(this);
		}
	}

	public final ProgramContext program() throws RecognitionException {
		ProgramContext _localctx = new ProgramContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_program);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(27);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Bool) | (1L << Int) | (1L << String) | (1L << Void) | (1L << Class) | (1L << Id))) != 0)) {
				{
				setState(25);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,0,_ctx) ) {
				case 1:
					{
					setState(22);
					func();
					}
					break;
				case 2:
					{
					setState(23);
					clas();
					}
					break;
				case 3:
					{
					setState(24);
					vari();
					}
					break;
				}
				}
				setState(29);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FuncContext extends ParserRuleContext {
		public List<TypeContext> type() {
			return getRuleContexts(TypeContext.class);
		}
		public TypeContext type(int i) {
			return getRuleContext(TypeContext.class,i);
		}
		public List<TerminalNode> Id() { return getTokens(emxstarParser.Id); }
		public TerminalNode Id(int i) {
			return getToken(emxstarParser.Id, i);
		}
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public FuncContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_func; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterFunc(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitFunc(this);
		}
	}

	public final FuncContext func() throws RecognitionException {
		FuncContext _localctx = new FuncContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_func);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(30);
			type();
			setState(31);
			match(Id);
			setState(32);
			match(T__0);
			setState(44);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Bool) | (1L << Int) | (1L << String) | (1L << Void) | (1L << Id))) != 0)) {
				{
				setState(33);
				type();
				setState(34);
				match(Id);
				setState(41);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__1) {
					{
					{
					setState(35);
					match(T__1);
					setState(36);
					type();
					setState(37);
					match(Id);
					}
					}
					setState(43);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
			}

			setState(46);
			match(T__2);
			setState(47);
			block();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FuncconContext extends ParserRuleContext {
		public TerminalNode Id() { return getToken(emxstarParser.Id, 0); }
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public FuncconContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_funccon; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterFunccon(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitFunccon(this);
		}
	}

	public final FuncconContext funccon() throws RecognitionException {
		FuncconContext _localctx = new FuncconContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_funccon);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(49);
			match(Id);
			setState(50);
			match(T__0);
			setState(51);
			match(T__2);
			setState(52);
			block();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VariContext extends ParserRuleContext {
		public TypeContext type() {
			return getRuleContext(TypeContext.class,0);
		}
		public TerminalNode Id() { return getToken(emxstarParser.Id, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public VariContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_vari; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterVari(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitVari(this);
		}
	}

	public final VariContext vari() throws RecognitionException {
		VariContext _localctx = new VariContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_vari);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(54);
			type();
			setState(55);
			match(Id);
			setState(58);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==T__3) {
				{
				setState(56);
				match(T__3);
				setState(57);
				expression(0);
				}
			}

			setState(60);
			match(T__4);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ClasContext extends ParserRuleContext {
		public TerminalNode Class() { return getToken(emxstarParser.Class, 0); }
		public TerminalNode Id() { return getToken(emxstarParser.Id, 0); }
		public List<FuncContext> func() {
			return getRuleContexts(FuncContext.class);
		}
		public FuncContext func(int i) {
			return getRuleContext(FuncContext.class,i);
		}
		public List<VariContext> vari() {
			return getRuleContexts(VariContext.class);
		}
		public VariContext vari(int i) {
			return getRuleContext(VariContext.class,i);
		}
		public FuncconContext funccon() {
			return getRuleContext(FuncconContext.class,0);
		}
		public ClasContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_clas; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterClas(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitClas(this);
		}
	}

	public final ClasContext clas() throws RecognitionException {
		ClasContext _localctx = new ClasContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_clas);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(62);
			match(Class);
			setState(63);
			match(Id);
			setState(64);
			match(T__5);
			setState(69);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,6,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					setState(67);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,5,_ctx) ) {
					case 1:
						{
						setState(65);
						func();
						}
						break;
					case 2:
						{
						setState(66);
						vari();
						}
						break;
					}
					} 
				}
				setState(71);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,6,_ctx);
			}
			setState(73);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,7,_ctx) ) {
			case 1:
				{
				setState(72);
				funccon();
				}
				break;
			}
			setState(79);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Bool) | (1L << Int) | (1L << String) | (1L << Void) | (1L << Id))) != 0)) {
				{
				setState(77);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,8,_ctx) ) {
				case 1:
					{
					setState(75);
					func();
					}
					break;
				case 2:
					{
					setState(76);
					vari();
					}
					break;
				}
				}
				setState(81);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(82);
			match(T__6);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TypeContext extends ParserRuleContext {
		public TerminalNode Int() { return getToken(emxstarParser.Int, 0); }
		public TerminalNode Bool() { return getToken(emxstarParser.Bool, 0); }
		public TerminalNode Id() { return getToken(emxstarParser.Id, 0); }
		public TerminalNode String() { return getToken(emxstarParser.String, 0); }
		public TerminalNode Void() { return getToken(emxstarParser.Void, 0); }
		public TypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_type; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitType(this);
		}
	}

	public final TypeContext type() throws RecognitionException {
		TypeContext _localctx = new TypeContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_type);
		int _la;
		try {
			setState(93);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case Bool:
			case Int:
			case String:
			case Id:
				enterOuterAlt(_localctx, 1);
				{
				{
				setState(84);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Bool) | (1L << Int) | (1L << String) | (1L << Id))) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(89);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==T__7) {
					{
					{
					setState(85);
					match(T__7);
					setState(86);
					match(T__8);
					}
					}
					setState(91);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				}
				break;
			case Void:
				enterOuterAlt(_localctx, 2);
				{
				setState(92);
				match(Void);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class BlockContext extends ParserRuleContext {
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public BlockContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_block; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterBlock(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitBlock(this);
		}
	}

	public final BlockContext block() throws RecognitionException {
		BlockContext _localctx = new BlockContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_block);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(95);
			match(T__5);
			setState(99);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__4) | (1L << T__5) | (1L << T__9) | (1L << T__10) | (1L << T__12) | (1L << T__13) | (1L << T__14) | (1L << T__15) | (1L << Bool) | (1L << Int) | (1L << String) | (1L << Null) | (1L << Void) | (1L << True) | (1L << False) | (1L << If) | (1L << For) | (1L << While) | (1L << Break) | (1L << Continue) | (1L << Return) | (1L << New) | (1L << This) | (1L << Id) | (1L << Stringcon) | (1L << Number))) != 0)) {
				{
				{
				setState(96);
				statement();
				}
				}
				setState(101);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(102);
			match(T__6);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StatementContext extends ParserRuleContext {
		public StatementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_statement; }
	 
		public StatementContext() { }
		public void copyFrom(StatementContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class S3Context extends StatementContext {
		public TerminalNode If() { return getToken(emxstarParser.If, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public List<StatementContext> statement() {
			return getRuleContexts(StatementContext.class);
		}
		public StatementContext statement(int i) {
			return getRuleContext(StatementContext.class,i);
		}
		public TerminalNode Else() { return getToken(emxstarParser.Else, 0); }
		public S3Context(StatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterS3(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitS3(this);
		}
	}
	public static class S4Context extends StatementContext {
		public TerminalNode While() { return getToken(emxstarParser.While, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public StatementContext statement() {
			return getRuleContext(StatementContext.class,0);
		}
		public S4Context(StatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterS4(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitS4(this);
		}
	}
	public static class S5Context extends StatementContext {
		public TerminalNode For() { return getToken(emxstarParser.For, 0); }
		public StatementContext statement() {
			return getRuleContext(StatementContext.class,0);
		}
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public S5Context(StatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterS5(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitS5(this);
		}
	}
	public static class S6Context extends StatementContext {
		public TerminalNode Continue() { return getToken(emxstarParser.Continue, 0); }
		public TerminalNode Break() { return getToken(emxstarParser.Break, 0); }
		public TerminalNode Return() { return getToken(emxstarParser.Return, 0); }
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public S6Context(StatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterS6(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitS6(this);
		}
	}
	public static class S7Context extends StatementContext {
		public VariContext vari() {
			return getRuleContext(VariContext.class,0);
		}
		public S7Context(StatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterS7(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitS7(this);
		}
	}
	public static class S1Context extends StatementContext {
		public BlockContext block() {
			return getRuleContext(BlockContext.class,0);
		}
		public S1Context(StatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterS1(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitS1(this);
		}
	}
	public static class S2Context extends StatementContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public S2Context(StatementContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterS2(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitS2(this);
		}
	}

	public final StatementContext statement() throws RecognitionException {
		StatementContext _localctx = new StatementContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_statement);
		int _la;
		try {
			setState(149);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,18,_ctx) ) {
			case 1:
				_localctx = new S1Context(_localctx);
				enterOuterAlt(_localctx, 1);
				{
				setState(104);
				block();
				}
				break;
			case 2:
				_localctx = new S2Context(_localctx);
				enterOuterAlt(_localctx, 2);
				{
				setState(105);
				expression(0);
				setState(106);
				match(T__4);
				}
				break;
			case 3:
				_localctx = new S3Context(_localctx);
				enterOuterAlt(_localctx, 3);
				{
				setState(108);
				match(If);
				setState(109);
				match(T__0);
				setState(110);
				expression(0);
				setState(111);
				match(T__2);
				setState(112);
				statement();
				setState(115);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,13,_ctx) ) {
				case 1:
					{
					setState(113);
					match(Else);
					setState(114);
					statement();
					}
					break;
				}
				}
				break;
			case 4:
				_localctx = new S4Context(_localctx);
				enterOuterAlt(_localctx, 4);
				{
				setState(117);
				match(While);
				setState(118);
				match(T__0);
				setState(119);
				expression(0);
				setState(120);
				match(T__2);
				setState(121);
				statement();
				}
				break;
			case 5:
				_localctx = new S5Context(_localctx);
				enterOuterAlt(_localctx, 5);
				{
				setState(123);
				match(For);
				setState(124);
				match(T__0);
				setState(126);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__9) | (1L << T__10) | (1L << T__12) | (1L << T__13) | (1L << T__14) | (1L << T__15) | (1L << Null) | (1L << True) | (1L << False) | (1L << New) | (1L << This) | (1L << Id) | (1L << Stringcon) | (1L << Number))) != 0)) {
					{
					setState(125);
					expression(0);
					}
				}

				setState(128);
				match(T__4);
				setState(130);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__9) | (1L << T__10) | (1L << T__12) | (1L << T__13) | (1L << T__14) | (1L << T__15) | (1L << Null) | (1L << True) | (1L << False) | (1L << New) | (1L << This) | (1L << Id) | (1L << Stringcon) | (1L << Number))) != 0)) {
					{
					setState(129);
					expression(0);
					}
				}

				setState(132);
				match(T__4);
				setState(134);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__9) | (1L << T__10) | (1L << T__12) | (1L << T__13) | (1L << T__14) | (1L << T__15) | (1L << Null) | (1L << True) | (1L << False) | (1L << New) | (1L << This) | (1L << Id) | (1L << Stringcon) | (1L << Number))) != 0)) {
					{
					setState(133);
					expression(0);
					}
				}

				setState(136);
				match(T__2);
				setState(137);
				statement();
				}
				break;
			case 6:
				_localctx = new S6Context(_localctx);
				enterOuterAlt(_localctx, 6);
				{
				setState(138);
				match(Continue);
				setState(139);
				match(T__4);
				}
				break;
			case 7:
				_localctx = new S6Context(_localctx);
				enterOuterAlt(_localctx, 7);
				{
				setState(140);
				match(Break);
				setState(141);
				match(T__4);
				}
				break;
			case 8:
				_localctx = new S6Context(_localctx);
				enterOuterAlt(_localctx, 8);
				{
				setState(142);
				match(Return);
				setState(144);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__9) | (1L << T__10) | (1L << T__12) | (1L << T__13) | (1L << T__14) | (1L << T__15) | (1L << Null) | (1L << True) | (1L << False) | (1L << New) | (1L << This) | (1L << Id) | (1L << Stringcon) | (1L << Number))) != 0)) {
					{
					setState(143);
					expression(0);
					}
				}

				setState(146);
				match(T__4);
				}
				break;
			case 9:
				_localctx = new S7Context(_localctx);
				enterOuterAlt(_localctx, 9);
				{
				setState(147);
				vari();
				}
				break;
			case 10:
				_localctx = new S2Context(_localctx);
				enterOuterAlt(_localctx, 10);
				{
				setState(148);
				match(T__4);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ExpressionContext extends ParserRuleContext {
		public ExpressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expression; }
	 
		public ExpressionContext() { }
		public void copyFrom(ExpressionContext ctx) {
			super.copyFrom(ctx);
		}
	}
	public static class E5Context extends ExpressionContext {
		public Token op;
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public E5Context(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterE5(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitE5(this);
		}
	}
	public static class E6Context extends ExpressionContext {
		public TerminalNode New() { return getToken(emxstarParser.New, 0); }
		public TerminalNode Id() { return getToken(emxstarParser.Id, 0); }
		public TerminalNode Int() { return getToken(emxstarParser.Int, 0); }
		public TerminalNode String() { return getToken(emxstarParser.String, 0); }
		public TerminalNode Bool() { return getToken(emxstarParser.Bool, 0); }
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public E6Context(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterE6(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitE6(this);
		}
	}
	public static class E7Context extends ExpressionContext {
		public ExpressionContext lhs;
		public Token op;
		public ExpressionContext rhs;
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public E7Context(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterE7(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitE7(this);
		}
	}
	public static class E8Context extends ExpressionContext {
		public NameContext name() {
			return getRuleContext(NameContext.class,0);
		}
		public ConstantContext constant() {
			return getRuleContext(ConstantContext.class,0);
		}
		public E8Context(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterE8(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitE8(this);
		}
	}
	public static class E9Context extends ExpressionContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public E9Context(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterE9(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitE9(this);
		}
	}
	public static class E1Context extends ExpressionContext {
		public Token op;
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public E1Context(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterE1(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitE1(this);
		}
	}
	public static class E2Context extends ExpressionContext {
		public ExpressionContext expression() {
			return getRuleContext(ExpressionContext.class,0);
		}
		public TerminalNode Id() { return getToken(emxstarParser.Id, 0); }
		public E2Context(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterE2(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitE2(this);
		}
	}
	public static class E3Context extends ExpressionContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public E3Context(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterE3(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitE3(this);
		}
	}
	public static class E4Context extends ExpressionContext {
		public List<ExpressionContext> expression() {
			return getRuleContexts(ExpressionContext.class);
		}
		public ExpressionContext expression(int i) {
			return getRuleContext(ExpressionContext.class,i);
		}
		public E4Context(ExpressionContext ctx) { copyFrom(ctx); }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterE4(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitE4(this);
		}
	}

	public final ExpressionContext expression() throws RecognitionException {
		return expression(0);
	}

	private ExpressionContext expression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExpressionContext _localctx = new ExpressionContext(_ctx, _parentState);
		ExpressionContext _prevctx = _localctx;
		int _startState = 16;
		enterRecursionRule(_localctx, 16, RULE_expression, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(176);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__9:
			case T__10:
			case T__12:
			case T__13:
			case T__14:
			case T__15:
				{
				_localctx = new E5Context(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;

				setState(152);
				((E5Context)_localctx).op = _input.LT(1);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__9) | (1L << T__10) | (1L << T__12) | (1L << T__13) | (1L << T__14) | (1L << T__15))) != 0)) ) {
					((E5Context)_localctx).op = (Token)_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(153);
				expression(16);
				}
				break;
			case New:
				{
				_localctx = new E6Context(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(154);
				match(New);
				setState(155);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Bool) | (1L << Int) | (1L << String) | (1L << Id))) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				setState(163);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,20,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(156);
						match(T__7);
						setState(158);
						_errHandler.sync(this);
						_la = _input.LA(1);
						if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__9) | (1L << T__10) | (1L << T__12) | (1L << T__13) | (1L << T__14) | (1L << T__15) | (1L << Null) | (1L << True) | (1L << False) | (1L << New) | (1L << This) | (1L << Id) | (1L << Stringcon) | (1L << Number))) != 0)) {
							{
							setState(157);
							expression(0);
							}
						}

						setState(160);
						match(T__8);
						}
						} 
					}
					setState(165);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,20,_ctx);
				}
				setState(168);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,21,_ctx) ) {
				case 1:
					{
					setState(166);
					match(T__0);
					setState(167);
					match(T__2);
					}
					break;
				}
				}
				break;
			case Id:
				{
				_localctx = new E8Context(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(170);
				name();
				}
				break;
			case Null:
			case True:
			case False:
			case This:
			case Stringcon:
			case Number:
				{
				_localctx = new E8Context(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(171);
				constant();
				}
				break;
			case T__0:
				{
				_localctx = new E9Context(_localctx);
				_ctx = _localctx;
				_prevctx = _localctx;
				setState(172);
				match(T__0);
				setState(173);
				expression(0);
				setState(174);
				match(T__2);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(248);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,28,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(246);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,27,_ctx) ) {
					case 1:
						{
						_localctx = new E7Context(new ExpressionContext(_parentctx, _parentState));
						((E7Context)_localctx).lhs = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(178);
						if (!(precpred(_ctx, 14))) throw new FailedPredicateException(this, "precpred(_ctx, 14)");
						setState(179);
						((E7Context)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__16) | (1L << T__17) | (1L << T__18))) != 0)) ) {
							((E7Context)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(180);
						((E7Context)_localctx).rhs = expression(15);
						}
						break;
					case 2:
						{
						_localctx = new E7Context(new ExpressionContext(_parentctx, _parentState));
						((E7Context)_localctx).lhs = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(181);
						if (!(precpred(_ctx, 13))) throw new FailedPredicateException(this, "precpred(_ctx, 13)");
						setState(182);
						((E7Context)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==T__12 || _la==T__13) ) {
							((E7Context)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(183);
						((E7Context)_localctx).rhs = expression(14);
						}
						break;
					case 3:
						{
						_localctx = new E7Context(new ExpressionContext(_parentctx, _parentState));
						((E7Context)_localctx).lhs = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(184);
						if (!(precpred(_ctx, 12))) throw new FailedPredicateException(this, "precpred(_ctx, 12)");
						setState(185);
						((E7Context)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==T__19 || _la==T__20) ) {
							((E7Context)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(186);
						((E7Context)_localctx).rhs = expression(13);
						}
						break;
					case 4:
						{
						_localctx = new E7Context(new ExpressionContext(_parentctx, _parentState));
						((E7Context)_localctx).lhs = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(187);
						if (!(precpred(_ctx, 11))) throw new FailedPredicateException(this, "precpred(_ctx, 11)");
						setState(188);
						((E7Context)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__21) | (1L << T__22) | (1L << T__23) | (1L << T__24))) != 0)) ) {
							((E7Context)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(189);
						((E7Context)_localctx).rhs = expression(12);
						}
						break;
					case 5:
						{
						_localctx = new E7Context(new ExpressionContext(_parentctx, _parentState));
						((E7Context)_localctx).lhs = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(190);
						if (!(precpred(_ctx, 10))) throw new FailedPredicateException(this, "precpred(_ctx, 10)");
						setState(191);
						((E7Context)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==T__25 || _la==T__26) ) {
							((E7Context)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(192);
						((E7Context)_localctx).rhs = expression(11);
						}
						break;
					case 6:
						{
						_localctx = new E7Context(new ExpressionContext(_parentctx, _parentState));
						((E7Context)_localctx).lhs = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(193);
						if (!(precpred(_ctx, 9))) throw new FailedPredicateException(this, "precpred(_ctx, 9)");
						setState(194);
						((E7Context)_localctx).op = match(T__27);
						setState(195);
						((E7Context)_localctx).rhs = expression(10);
						}
						break;
					case 7:
						{
						_localctx = new E7Context(new ExpressionContext(_parentctx, _parentState));
						((E7Context)_localctx).lhs = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(196);
						if (!(precpred(_ctx, 8))) throw new FailedPredicateException(this, "precpred(_ctx, 8)");
						setState(197);
						((E7Context)_localctx).op = match(T__28);
						setState(198);
						((E7Context)_localctx).rhs = expression(9);
						}
						break;
					case 8:
						{
						_localctx = new E7Context(new ExpressionContext(_parentctx, _parentState));
						((E7Context)_localctx).lhs = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(199);
						if (!(precpred(_ctx, 7))) throw new FailedPredicateException(this, "precpred(_ctx, 7)");
						setState(200);
						((E7Context)_localctx).op = match(T__29);
						setState(201);
						((E7Context)_localctx).rhs = expression(8);
						}
						break;
					case 9:
						{
						_localctx = new E7Context(new ExpressionContext(_parentctx, _parentState));
						((E7Context)_localctx).lhs = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(202);
						if (!(precpred(_ctx, 6))) throw new FailedPredicateException(this, "precpred(_ctx, 6)");
						setState(203);
						((E7Context)_localctx).op = match(T__30);
						setState(204);
						((E7Context)_localctx).rhs = expression(7);
						}
						break;
					case 10:
						{
						_localctx = new E7Context(new ExpressionContext(_parentctx, _parentState));
						((E7Context)_localctx).lhs = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(205);
						if (!(precpred(_ctx, 5))) throw new FailedPredicateException(this, "precpred(_ctx, 5)");
						setState(206);
						((E7Context)_localctx).op = match(T__31);
						setState(207);
						((E7Context)_localctx).rhs = expression(6);
						}
						break;
					case 11:
						{
						_localctx = new E7Context(new ExpressionContext(_parentctx, _parentState));
						((E7Context)_localctx).lhs = _prevctx;
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(208);
						if (!(precpred(_ctx, 4))) throw new FailedPredicateException(this, "precpred(_ctx, 4)");
						setState(209);
						((E7Context)_localctx).op = match(T__3);
						setState(210);
						((E7Context)_localctx).rhs = expression(4);
						}
						break;
					case 12:
						{
						_localctx = new E1Context(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(211);
						if (!(precpred(_ctx, 20))) throw new FailedPredicateException(this, "precpred(_ctx, 20)");
						setState(212);
						((E1Context)_localctx).op = _input.LT(1);
						_la = _input.LA(1);
						if ( !(_la==T__9 || _la==T__10) ) {
							((E1Context)_localctx).op = (Token)_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						}
						break;
					case 13:
						{
						_localctx = new E2Context(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(213);
						if (!(precpred(_ctx, 19))) throw new FailedPredicateException(this, "precpred(_ctx, 19)");
						setState(214);
						match(T__11);
						setState(218);
						_errHandler.sync(this);
						_la = _input.LA(1);
						while (_la==T__0) {
							{
							{
							setState(215);
							match(T__0);
							}
							}
							setState(220);
							_errHandler.sync(this);
							_la = _input.LA(1);
						}
						setState(221);
						match(Id);
						setState(225);
						_errHandler.sync(this);
						_alt = getInterpreter().adaptivePredict(_input,24,_ctx);
						while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
							if ( _alt==1 ) {
								{
								{
								setState(222);
								match(T__2);
								}
								} 
							}
							setState(227);
							_errHandler.sync(this);
							_alt = getInterpreter().adaptivePredict(_input,24,_ctx);
						}
						}
						break;
					case 14:
						{
						_localctx = new E3Context(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(228);
						if (!(precpred(_ctx, 18))) throw new FailedPredicateException(this, "precpred(_ctx, 18)");
						setState(229);
						match(T__7);
						setState(230);
						expression(0);
						setState(231);
						match(T__8);
						}
						break;
					case 15:
						{
						_localctx = new E4Context(new ExpressionContext(_parentctx, _parentState));
						pushNewRecursionContext(_localctx, _startState, RULE_expression);
						setState(233);
						if (!(precpred(_ctx, 17))) throw new FailedPredicateException(this, "precpred(_ctx, 17)");
						setState(234);
						match(T__0);
						setState(243);
						_errHandler.sync(this);
						_la = _input.LA(1);
						if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__9) | (1L << T__10) | (1L << T__12) | (1L << T__13) | (1L << T__14) | (1L << T__15) | (1L << Null) | (1L << True) | (1L << False) | (1L << New) | (1L << This) | (1L << Id) | (1L << Stringcon) | (1L << Number))) != 0)) {
							{
							setState(235);
							expression(0);
							setState(240);
							_errHandler.sync(this);
							_la = _input.LA(1);
							while (_la==T__1) {
								{
								{
								setState(236);
								match(T__1);
								setState(237);
								expression(0);
								}
								}
								setState(242);
								_errHandler.sync(this);
								_la = _input.LA(1);
							}
							}
						}

						setState(245);
						match(T__2);
						}
						break;
					}
					} 
				}
				setState(250);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,28,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class ConstantContext extends ParserRuleContext {
		public TerminalNode True() { return getToken(emxstarParser.True, 0); }
		public TerminalNode False() { return getToken(emxstarParser.False, 0); }
		public TerminalNode Stringcon() { return getToken(emxstarParser.Stringcon, 0); }
		public TerminalNode Number() { return getToken(emxstarParser.Number, 0); }
		public TerminalNode Null() { return getToken(emxstarParser.Null, 0); }
		public TerminalNode This() { return getToken(emxstarParser.This, 0); }
		public ConstantContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constant; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterConstant(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitConstant(this);
		}
	}

	public final ConstantContext constant() throws RecognitionException {
		ConstantContext _localctx = new ConstantContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_constant);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(251);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << Null) | (1L << True) | (1L << False) | (1L << This) | (1L << Stringcon) | (1L << Number))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NameContext extends ParserRuleContext {
		public TerminalNode Id() { return getToken(emxstarParser.Id, 0); }
		public NameContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_name; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).enterName(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof emxstarListener ) ((emxstarListener)listener).exitName(this);
		}
	}

	public final NameContext name() throws RecognitionException {
		NameContext _localctx = new NameContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_name);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(253);
			match(Id);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 8:
			return expression_sempred((ExpressionContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean expression_sempred(ExpressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 14);
		case 1:
			return precpred(_ctx, 13);
		case 2:
			return precpred(_ctx, 12);
		case 3:
			return precpred(_ctx, 11);
		case 4:
			return precpred(_ctx, 10);
		case 5:
			return precpred(_ctx, 9);
		case 6:
			return precpred(_ctx, 8);
		case 7:
			return precpred(_ctx, 7);
		case 8:
			return precpred(_ctx, 6);
		case 9:
			return precpred(_ctx, 5);
		case 10:
			return precpred(_ctx, 4);
		case 11:
			return precpred(_ctx, 20);
		case 12:
			return precpred(_ctx, 19);
		case 13:
			return precpred(_ctx, 18);
		case 14:
			return precpred(_ctx, 17);
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\39\u0102\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\3\2\3\2\3\2\7\2\34\n\2\f\2\16\2\37\13\2\3\3\3\3\3\3\3\3\3"+
		"\3\3\3\3\3\3\3\3\3\7\3*\n\3\f\3\16\3-\13\3\5\3/\n\3\3\3\3\3\3\3\3\4\3"+
		"\4\3\4\3\4\3\4\3\5\3\5\3\5\3\5\5\5=\n\5\3\5\3\5\3\6\3\6\3\6\3\6\3\6\7"+
		"\6F\n\6\f\6\16\6I\13\6\3\6\5\6L\n\6\3\6\3\6\7\6P\n\6\f\6\16\6S\13\6\3"+
		"\6\3\6\3\7\3\7\3\7\7\7Z\n\7\f\7\16\7]\13\7\3\7\5\7`\n\7\3\b\3\b\7\bd\n"+
		"\b\f\b\16\bg\13\b\3\b\3\b\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t"+
		"\5\tv\n\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\5\t\u0081\n\t\3\t\3\t\5"+
		"\t\u0085\n\t\3\t\3\t\5\t\u0089\n\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\5\t"+
		"\u0093\n\t\3\t\3\t\3\t\5\t\u0098\n\t\3\n\3\n\3\n\3\n\3\n\3\n\3\n\5\n\u00a1"+
		"\n\n\3\n\7\n\u00a4\n\n\f\n\16\n\u00a7\13\n\3\n\3\n\5\n\u00ab\n\n\3\n\3"+
		"\n\3\n\3\n\3\n\3\n\5\n\u00b3\n\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3"+
		"\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n"+
		"\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\7\n\u00db\n\n\f\n\16\n\u00de"+
		"\13\n\3\n\3\n\7\n\u00e2\n\n\f\n\16\n\u00e5\13\n\3\n\3\n\3\n\3\n\3\n\3"+
		"\n\3\n\3\n\3\n\3\n\7\n\u00f1\n\n\f\n\16\n\u00f4\13\n\5\n\u00f6\n\n\3\n"+
		"\7\n\u00f9\n\n\f\n\16\n\u00fc\13\n\3\13\3\13\3\f\3\f\3\f\2\3\22\r\2\4"+
		"\6\b\n\f\16\20\22\24\26\2\13\4\2#%\64\64\4\2\f\r\17\22\3\2\23\25\3\2\17"+
		"\20\3\2\26\27\3\2\30\33\3\2\34\35\3\2\f\r\6\2&&()\63\63\65\66\2\u012c"+
		"\2\35\3\2\2\2\4 \3\2\2\2\6\63\3\2\2\2\b8\3\2\2\2\n@\3\2\2\2\f_\3\2\2\2"+
		"\16a\3\2\2\2\20\u0097\3\2\2\2\22\u00b2\3\2\2\2\24\u00fd\3\2\2\2\26\u00ff"+
		"\3\2\2\2\30\34\5\4\3\2\31\34\5\n\6\2\32\34\5\b\5\2\33\30\3\2\2\2\33\31"+
		"\3\2\2\2\33\32\3\2\2\2\34\37\3\2\2\2\35\33\3\2\2\2\35\36\3\2\2\2\36\3"+
		"\3\2\2\2\37\35\3\2\2\2 !\5\f\7\2!\"\7\64\2\2\".\7\3\2\2#$\5\f\7\2$+\7"+
		"\64\2\2%&\7\4\2\2&\'\5\f\7\2\'(\7\64\2\2(*\3\2\2\2)%\3\2\2\2*-\3\2\2\2"+
		"+)\3\2\2\2+,\3\2\2\2,/\3\2\2\2-+\3\2\2\2.#\3\2\2\2./\3\2\2\2/\60\3\2\2"+
		"\2\60\61\7\5\2\2\61\62\5\16\b\2\62\5\3\2\2\2\63\64\7\64\2\2\64\65\7\3"+
		"\2\2\65\66\7\5\2\2\66\67\5\16\b\2\67\7\3\2\2\289\5\f\7\29<\7\64\2\2:;"+
		"\7\6\2\2;=\5\22\n\2<:\3\2\2\2<=\3\2\2\2=>\3\2\2\2>?\7\7\2\2?\t\3\2\2\2"+
		"@A\7\62\2\2AB\7\64\2\2BG\7\b\2\2CF\5\4\3\2DF\5\b\5\2EC\3\2\2\2ED\3\2\2"+
		"\2FI\3\2\2\2GE\3\2\2\2GH\3\2\2\2HK\3\2\2\2IG\3\2\2\2JL\5\6\4\2KJ\3\2\2"+
		"\2KL\3\2\2\2LQ\3\2\2\2MP\5\4\3\2NP\5\b\5\2OM\3\2\2\2ON\3\2\2\2PS\3\2\2"+
		"\2QO\3\2\2\2QR\3\2\2\2RT\3\2\2\2SQ\3\2\2\2TU\7\t\2\2U\13\3\2\2\2V[\t\2"+
		"\2\2WX\7\n\2\2XZ\7\13\2\2YW\3\2\2\2Z]\3\2\2\2[Y\3\2\2\2[\\\3\2\2\2\\`"+
		"\3\2\2\2][\3\2\2\2^`\7\'\2\2_V\3\2\2\2_^\3\2\2\2`\r\3\2\2\2ae\7\b\2\2"+
		"bd\5\20\t\2cb\3\2\2\2dg\3\2\2\2ec\3\2\2\2ef\3\2\2\2fh\3\2\2\2ge\3\2\2"+
		"\2hi\7\t\2\2i\17\3\2\2\2j\u0098\5\16\b\2kl\5\22\n\2lm\7\7\2\2m\u0098\3"+
		"\2\2\2no\7*\2\2op\7\3\2\2pq\5\22\n\2qr\7\5\2\2ru\5\20\t\2st\7+\2\2tv\5"+
		"\20\t\2us\3\2\2\2uv\3\2\2\2v\u0098\3\2\2\2wx\7-\2\2xy\7\3\2\2yz\5\22\n"+
		"\2z{\7\5\2\2{|\5\20\t\2|\u0098\3\2\2\2}~\7,\2\2~\u0080\7\3\2\2\177\u0081"+
		"\5\22\n\2\u0080\177\3\2\2\2\u0080\u0081\3\2\2\2\u0081\u0082\3\2\2\2\u0082"+
		"\u0084\7\7\2\2\u0083\u0085\5\22\n\2\u0084\u0083\3\2\2\2\u0084\u0085\3"+
		"\2\2\2\u0085\u0086\3\2\2\2\u0086\u0088\7\7\2\2\u0087\u0089\5\22\n\2\u0088"+
		"\u0087\3\2\2\2\u0088\u0089\3\2\2\2\u0089\u008a\3\2\2\2\u008a\u008b\7\5"+
		"\2\2\u008b\u0098\5\20\t\2\u008c\u008d\7/\2\2\u008d\u0098\7\7\2\2\u008e"+
		"\u008f\7.\2\2\u008f\u0098\7\7\2\2\u0090\u0092\7\60\2\2\u0091\u0093\5\22"+
		"\n\2\u0092\u0091\3\2\2\2\u0092\u0093\3\2\2\2\u0093\u0094\3\2\2\2\u0094"+
		"\u0098\7\7\2\2\u0095\u0098\5\b\5\2\u0096\u0098\7\7\2\2\u0097j\3\2\2\2"+
		"\u0097k\3\2\2\2\u0097n\3\2\2\2\u0097w\3\2\2\2\u0097}\3\2\2\2\u0097\u008c"+
		"\3\2\2\2\u0097\u008e\3\2\2\2\u0097\u0090\3\2\2\2\u0097\u0095\3\2\2\2\u0097"+
		"\u0096\3\2\2\2\u0098\21\3\2\2\2\u0099\u009a\b\n\1\2\u009a\u009b\t\3\2"+
		"\2\u009b\u00b3\5\22\n\22\u009c\u009d\7\61\2\2\u009d\u00a5\t\2\2\2\u009e"+
		"\u00a0\7\n\2\2\u009f\u00a1\5\22\n\2\u00a0\u009f\3\2\2\2\u00a0\u00a1\3"+
		"\2\2\2\u00a1\u00a2\3\2\2\2\u00a2\u00a4\7\13\2\2\u00a3\u009e\3\2\2\2\u00a4"+
		"\u00a7\3\2\2\2\u00a5\u00a3\3\2\2\2\u00a5\u00a6\3\2\2\2\u00a6\u00aa\3\2"+
		"\2\2\u00a7\u00a5\3\2\2\2\u00a8\u00a9\7\3\2\2\u00a9\u00ab\7\5\2\2\u00aa"+
		"\u00a8\3\2\2\2\u00aa\u00ab\3\2\2\2\u00ab\u00b3\3\2\2\2\u00ac\u00b3\5\26"+
		"\f\2\u00ad\u00b3\5\24\13\2\u00ae\u00af\7\3\2\2\u00af\u00b0\5\22\n\2\u00b0"+
		"\u00b1\7\5\2\2\u00b1\u00b3\3\2\2\2\u00b2\u0099\3\2\2\2\u00b2\u009c\3\2"+
		"\2\2\u00b2\u00ac\3\2\2\2\u00b2\u00ad\3\2\2\2\u00b2\u00ae\3\2\2\2\u00b3"+
		"\u00fa\3\2\2\2\u00b4\u00b5\f\20\2\2\u00b5\u00b6\t\4\2\2\u00b6\u00f9\5"+
		"\22\n\21\u00b7\u00b8\f\17\2\2\u00b8\u00b9\t\5\2\2\u00b9\u00f9\5\22\n\20"+
		"\u00ba\u00bb\f\16\2\2\u00bb\u00bc\t\6\2\2\u00bc\u00f9\5\22\n\17\u00bd"+
		"\u00be\f\r\2\2\u00be\u00bf\t\7\2\2\u00bf\u00f9\5\22\n\16\u00c0\u00c1\f"+
		"\f\2\2\u00c1\u00c2\t\b\2\2\u00c2\u00f9\5\22\n\r\u00c3\u00c4\f\13\2\2\u00c4"+
		"\u00c5\7\36\2\2\u00c5\u00f9\5\22\n\f\u00c6\u00c7\f\n\2\2\u00c7\u00c8\7"+
		"\37\2\2\u00c8\u00f9\5\22\n\13\u00c9\u00ca\f\t\2\2\u00ca\u00cb\7 \2\2\u00cb"+
		"\u00f9\5\22\n\n\u00cc\u00cd\f\b\2\2\u00cd\u00ce\7!\2\2\u00ce\u00f9\5\22"+
		"\n\t\u00cf\u00d0\f\7\2\2\u00d0\u00d1\7\"\2\2\u00d1\u00f9\5\22\n\b\u00d2"+
		"\u00d3\f\6\2\2\u00d3\u00d4\7\6\2\2\u00d4\u00f9\5\22\n\6\u00d5\u00d6\f"+
		"\26\2\2\u00d6\u00f9\t\t\2\2\u00d7\u00d8\f\25\2\2\u00d8\u00dc\7\16\2\2"+
		"\u00d9\u00db\7\3\2\2\u00da\u00d9\3\2\2\2\u00db\u00de\3\2\2\2\u00dc\u00da"+
		"\3\2\2\2\u00dc\u00dd\3\2\2\2\u00dd\u00df\3\2\2\2\u00de\u00dc\3\2\2\2\u00df"+
		"\u00e3\7\64\2\2\u00e0\u00e2\7\5\2\2\u00e1\u00e0\3\2\2\2\u00e2\u00e5\3"+
		"\2\2\2\u00e3\u00e1\3\2\2\2\u00e3\u00e4\3\2\2\2\u00e4\u00f9\3\2\2\2\u00e5"+
		"\u00e3\3\2\2\2\u00e6\u00e7\f\24\2\2\u00e7\u00e8\7\n\2\2\u00e8\u00e9\5"+
		"\22\n\2\u00e9\u00ea\7\13\2\2\u00ea\u00f9\3\2\2\2\u00eb\u00ec\f\23\2\2"+
		"\u00ec\u00f5\7\3\2\2\u00ed\u00f2\5\22\n\2\u00ee\u00ef\7\4\2\2\u00ef\u00f1"+
		"\5\22\n\2\u00f0\u00ee\3\2\2\2\u00f1\u00f4\3\2\2\2\u00f2\u00f0\3\2\2\2"+
		"\u00f2\u00f3\3\2\2\2\u00f3\u00f6\3\2\2\2\u00f4\u00f2\3\2\2\2\u00f5\u00ed"+
		"\3\2\2\2\u00f5\u00f6\3\2\2\2\u00f6\u00f7\3\2\2\2\u00f7\u00f9\7\5\2\2\u00f8"+
		"\u00b4\3\2\2\2\u00f8\u00b7\3\2\2\2\u00f8\u00ba\3\2\2\2\u00f8\u00bd\3\2"+
		"\2\2\u00f8\u00c0\3\2\2\2\u00f8\u00c3\3\2\2\2\u00f8\u00c6\3\2\2\2\u00f8"+
		"\u00c9\3\2\2\2\u00f8\u00cc\3\2\2\2\u00f8\u00cf\3\2\2\2\u00f8\u00d2\3\2"+
		"\2\2\u00f8\u00d5\3\2\2\2\u00f8\u00d7\3\2\2\2\u00f8\u00e6\3\2\2\2\u00f8"+
		"\u00eb\3\2\2\2\u00f9\u00fc\3\2\2\2\u00fa\u00f8\3\2\2\2\u00fa\u00fb\3\2"+
		"\2\2\u00fb\23\3\2\2\2\u00fc\u00fa\3\2\2\2\u00fd\u00fe\t\n\2\2\u00fe\25"+
		"\3\2\2\2\u00ff\u0100\7\64\2\2\u0100\27\3\2\2\2\37\33\35+.<EGKOQ[_eu\u0080"+
		"\u0084\u0088\u0092\u0097\u00a0\u00a5\u00aa\u00b2\u00dc\u00e3\u00f2\u00f5"+
		"\u00f8\u00fa";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}