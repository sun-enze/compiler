// Generated from emxstar.g4 by ANTLR 4.7.2
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link emxstarParser}.
 */
public interface emxstarListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link emxstarParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(emxstarParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link emxstarParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(emxstarParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link emxstarParser#func}.
	 * @param ctx the parse tree
	 */
	void enterFunc(emxstarParser.FuncContext ctx);
	/**
	 * Exit a parse tree produced by {@link emxstarParser#func}.
	 * @param ctx the parse tree
	 */
	void exitFunc(emxstarParser.FuncContext ctx);
	/**
	 * Enter a parse tree produced by {@link emxstarParser#funccon}.
	 * @param ctx the parse tree
	 */
	void enterFunccon(emxstarParser.FuncconContext ctx);
	/**
	 * Exit a parse tree produced by {@link emxstarParser#funccon}.
	 * @param ctx the parse tree
	 */
	void exitFunccon(emxstarParser.FuncconContext ctx);
	/**
	 * Enter a parse tree produced by {@link emxstarParser#vari}.
	 * @param ctx the parse tree
	 */
	void enterVari(emxstarParser.VariContext ctx);
	/**
	 * Exit a parse tree produced by {@link emxstarParser#vari}.
	 * @param ctx the parse tree
	 */
	void exitVari(emxstarParser.VariContext ctx);
	/**
	 * Enter a parse tree produced by {@link emxstarParser#clas}.
	 * @param ctx the parse tree
	 */
	void enterClas(emxstarParser.ClasContext ctx);
	/**
	 * Exit a parse tree produced by {@link emxstarParser#clas}.
	 * @param ctx the parse tree
	 */
	void exitClas(emxstarParser.ClasContext ctx);
	/**
	 * Enter a parse tree produced by {@link emxstarParser#type}.
	 * @param ctx the parse tree
	 */
	void enterType(emxstarParser.TypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link emxstarParser#type}.
	 * @param ctx the parse tree
	 */
	void exitType(emxstarParser.TypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link emxstarParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(emxstarParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link emxstarParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(emxstarParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code s1}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterS1(emxstarParser.S1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code s1}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitS1(emxstarParser.S1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code s2}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterS2(emxstarParser.S2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code s2}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitS2(emxstarParser.S2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code s3}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterS3(emxstarParser.S3Context ctx);
	/**
	 * Exit a parse tree produced by the {@code s3}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitS3(emxstarParser.S3Context ctx);
	/**
	 * Enter a parse tree produced by the {@code s4}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterS4(emxstarParser.S4Context ctx);
	/**
	 * Exit a parse tree produced by the {@code s4}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitS4(emxstarParser.S4Context ctx);
	/**
	 * Enter a parse tree produced by the {@code s5}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterS5(emxstarParser.S5Context ctx);
	/**
	 * Exit a parse tree produced by the {@code s5}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitS5(emxstarParser.S5Context ctx);
	/**
	 * Enter a parse tree produced by the {@code s6}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterS6(emxstarParser.S6Context ctx);
	/**
	 * Exit a parse tree produced by the {@code s6}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitS6(emxstarParser.S6Context ctx);
	/**
	 * Enter a parse tree produced by the {@code s7}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterS7(emxstarParser.S7Context ctx);
	/**
	 * Exit a parse tree produced by the {@code s7}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitS7(emxstarParser.S7Context ctx);
	/**
	 * Enter a parse tree produced by the {@code e5}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterE5(emxstarParser.E5Context ctx);
	/**
	 * Exit a parse tree produced by the {@code e5}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitE5(emxstarParser.E5Context ctx);
	/**
	 * Enter a parse tree produced by the {@code e6}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterE6(emxstarParser.E6Context ctx);
	/**
	 * Exit a parse tree produced by the {@code e6}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitE6(emxstarParser.E6Context ctx);
	/**
	 * Enter a parse tree produced by the {@code e7}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterE7(emxstarParser.E7Context ctx);
	/**
	 * Exit a parse tree produced by the {@code e7}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitE7(emxstarParser.E7Context ctx);
	/**
	 * Enter a parse tree produced by the {@code e8}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterE8(emxstarParser.E8Context ctx);
	/**
	 * Exit a parse tree produced by the {@code e8}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitE8(emxstarParser.E8Context ctx);
	/**
	 * Enter a parse tree produced by the {@code e9}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterE9(emxstarParser.E9Context ctx);
	/**
	 * Exit a parse tree produced by the {@code e9}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitE9(emxstarParser.E9Context ctx);
	/**
	 * Enter a parse tree produced by the {@code e1}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterE1(emxstarParser.E1Context ctx);
	/**
	 * Exit a parse tree produced by the {@code e1}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitE1(emxstarParser.E1Context ctx);
	/**
	 * Enter a parse tree produced by the {@code e2}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterE2(emxstarParser.E2Context ctx);
	/**
	 * Exit a parse tree produced by the {@code e2}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitE2(emxstarParser.E2Context ctx);
	/**
	 * Enter a parse tree produced by the {@code e3}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterE3(emxstarParser.E3Context ctx);
	/**
	 * Exit a parse tree produced by the {@code e3}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitE3(emxstarParser.E3Context ctx);
	/**
	 * Enter a parse tree produced by the {@code e4}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterE4(emxstarParser.E4Context ctx);
	/**
	 * Exit a parse tree produced by the {@code e4}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitE4(emxstarParser.E4Context ctx);
	/**
	 * Enter a parse tree produced by {@link emxstarParser#constant}.
	 * @param ctx the parse tree
	 */
	void enterConstant(emxstarParser.ConstantContext ctx);
	/**
	 * Exit a parse tree produced by {@link emxstarParser#constant}.
	 * @param ctx the parse tree
	 */
	void exitConstant(emxstarParser.ConstantContext ctx);
	/**
	 * Enter a parse tree produced by {@link emxstarParser#name}.
	 * @param ctx the parse tree
	 */
	void enterName(emxstarParser.NameContext ctx);
	/**
	 * Exit a parse tree produced by {@link emxstarParser#name}.
	 * @param ctx the parse tree
	 */
	void exitName(emxstarParser.NameContext ctx);
}