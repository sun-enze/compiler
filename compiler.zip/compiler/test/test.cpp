
int main() {
	int a = 1;
	print(tostring(a));
}




