package com.evensgn.emcompiler.scope;
import java.util.HashMap;
import java.util.Map;
public class scope{
	
}
