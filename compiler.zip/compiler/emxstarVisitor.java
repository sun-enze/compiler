// Generated from emxstar.g4 by ANTLR 4.7.2
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link emxstarParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface emxstarVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link emxstarParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(emxstarParser.ProgramContext ctx);
	/**
	 * Visit a parse tree produced by {@link emxstarParser#func}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunc(emxstarParser.FuncContext ctx);
	/**
	 * Visit a parse tree produced by {@link emxstarParser#funccon}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFunccon(emxstarParser.FuncconContext ctx);
	/**
	 * Visit a parse tree produced by {@link emxstarParser#vari}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVari(emxstarParser.VariContext ctx);
	/**
	 * Visit a parse tree produced by {@link emxstarParser#clas}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClas(emxstarParser.ClasContext ctx);
	/**
	 * Visit a parse tree produced by {@link emxstarParser#type}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitType(emxstarParser.TypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link emxstarParser#block}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlock(emxstarParser.BlockContext ctx);
	/**
	 * Visit a parse tree produced by the {@code s1}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitS1(emxstarParser.S1Context ctx);
	/**
	 * Visit a parse tree produced by the {@code s2}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitS2(emxstarParser.S2Context ctx);
	/**
	 * Visit a parse tree produced by the {@code s3}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitS3(emxstarParser.S3Context ctx);
	/**
	 * Visit a parse tree produced by the {@code s4}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitS4(emxstarParser.S4Context ctx);
	/**
	 * Visit a parse tree produced by the {@code s5}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitS5(emxstarParser.S5Context ctx);
	/**
	 * Visit a parse tree produced by the {@code s6}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitS6(emxstarParser.S6Context ctx);
	/**
	 * Visit a parse tree produced by the {@code s7}
	 * labeled alternative in {@link emxstarParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitS7(emxstarParser.S7Context ctx);
	/**
	 * Visit a parse tree produced by the {@code e5}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitE5(emxstarParser.E5Context ctx);
	/**
	 * Visit a parse tree produced by the {@code e6}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitE6(emxstarParser.E6Context ctx);
	/**
	 * Visit a parse tree produced by the {@code e7}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitE7(emxstarParser.E7Context ctx);
	/**
	 * Visit a parse tree produced by the {@code e8}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitE8(emxstarParser.E8Context ctx);
	/**
	 * Visit a parse tree produced by the {@code e9}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitE9(emxstarParser.E9Context ctx);
	/**
	 * Visit a parse tree produced by the {@code e1}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitE1(emxstarParser.E1Context ctx);
	/**
	 * Visit a parse tree produced by the {@code e2}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitE2(emxstarParser.E2Context ctx);
	/**
	 * Visit a parse tree produced by the {@code e3}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitE3(emxstarParser.E3Context ctx);
	/**
	 * Visit a parse tree produced by the {@code e4}
	 * labeled alternative in {@link emxstarParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitE4(emxstarParser.E4Context ctx);
	/**
	 * Visit a parse tree produced by {@link emxstarParser#constant}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConstant(emxstarParser.ConstantContext ctx);
	/**
	 * Visit a parse tree produced by {@link emxstarParser#name}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitName(emxstarParser.NameContext ctx);
}